// import {Injectable} from '@angular/core';
// import {SearchFilter} from '../models/search-filter.model';
// import {LocalCollection} from '../../backbone/collections/local.collection';
//
// @Injectable()
// export class SearchFilters <TModel extends SearchFilter> extends LocalCollection<SearchFilter> {
//   model: any = SearchFilter;
//   localStoreId: string = 'sc_search_filters';
// }
