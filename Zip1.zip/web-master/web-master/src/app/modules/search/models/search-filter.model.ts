// import {Injectable} from '@angular/core';
// import localforage = require('localforage');
// import {LocalModel} from '../../backbone/models/local.model';
//
// @Injectable()
// export class SearchFilter extends LocalModel {
//   localStoreId: string = 'sc_search_filters';
// }
