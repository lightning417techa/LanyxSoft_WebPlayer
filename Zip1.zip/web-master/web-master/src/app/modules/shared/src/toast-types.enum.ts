export enum ToastTypes {
  DefaultToast = 'default',
  Info = 'info',
  Warning = 'warning',
  Danger = 'danger',
  Primary = 'primary'
}
