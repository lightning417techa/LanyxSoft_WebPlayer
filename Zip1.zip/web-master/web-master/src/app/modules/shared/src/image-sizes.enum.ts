export enum ImageSizes {
  Small,
  Medium,
  Large
}
