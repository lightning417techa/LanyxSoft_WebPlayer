const soundCloudredirectDomain = 'https://sc.menu-flow.com';

export const Globals = {
  soundcloudClientId: 'mqCVRxAeYDUjlPhqj27Hb1H9kydm9fMm',
  soundcloudRedirectDomain: soundCloudredirectDomain,
  soundcloudRedirectUrl: soundCloudredirectDomain + '/connect',
  youtubeClientId: 'AIzaSyChl_ZzHjy7qX1A48q-P63SjffSHVvb9aE'
};
